const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/portfolio', { useNewUrlParser: true, useUnifiedTopology: true });

// Mongoose schema and model
const contactSchema = new mongoose.Schema({
    name: String,
    email: String,
    message: String
});

const Contact = mongoose.model('Contact', contactSchema);

// API endpoint for contact form submissions
app.post('/api/contact', (req, res) => {
    const { name, email, message } = req.body;

    const newContact = new Contact({ name, email, message });

    newContact.save()
        .then(() => res.status(200).json({ message: 'Message sent successfully!' }))
        .catch(error => res.status(500).json({ message: 'There was an error sending your message.', error }));
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});